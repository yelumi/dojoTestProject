let express = require ('express')
let app = express()
let mongoose = require('mongoose') 
let bodyParser = require('body-parser')
const bcrypt = require('bcrypt')
const passport = require('passport')
const initializePassport = require('./passport-config')
initializePassport.fonction(
    passport
)
const users = []
const flash = require('express-flash')
const session = require('express-session')

//moteur de template
app.set('view engine','ejs')

//middleware
app.use('/assets',express.static('public'))
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())
app.use(flash())
app.use(session({
    secret: 'hgjgkfhvbn',
    resave: false,
    saveUninitialized: false,
}))
app.use(passport.initialize())
app.use(passport.session())

//construction des schémas mongodb
mongoose.connect('mongodb://localhost/base',{useUnifiedTopology: true,useNewUrlParser: true})
let submissionSchema = mongoose.Schema({
    nom:String,
    prenoms:String,
    age:Number,
    experience:String,
    motivation:String,
    statut:String
});
const Submission = mongoose.model('Submission',submissionSchema)

let userSchema = mongoose.Schema({
    nom:String,
    mail:String,
    passe:String,
});
const User = mongoose.model('User',userSchema)

//routes de données
app.route('/').get((req,res)=>{
        res.render('pages/index')
        res.end    
    });
app.route('/').post((req,res)=>{
        let submission = new Submission()
        submission.nom = req.body.nom
        submission.prenoms = req.body.prenoms
        submission.age = req.body.age
        submission.experience = req.body.experience
        submission.motivation = req.body.motivation
        submission.statut = 's'
        submission.save(function(err){
            if(err){
                res.send(err)
            }
        res.render('pages/thanks')
        });
    });
app.route('/submissionsS').get((req,res)=>{
        Submission.find({statut:"s"},(err,submissions)=>{
            if(err){
                resp.send(err);
            }
            res.render('pages/submissionsS',{submissions:submissions})
        });
        res.end    
    });

app.route('/submissionsV').get((req,res)=>{
        Submission.find({statut:"v"},(err,submissions)=>{
            if(err){
                resp.send(err);
            }
            res.render('pages/submissionsAccepted',{submissions:submissions})
        });
        res.end    
    });
       
app.route('/submissionsR').get((req,res)=>{
        Submission.find({statut:"r"},(err,submissions)=>{
            if(err){
                resp.send(err);
            }
            res.render('pages/submissionsRejected',{submissions:submissions})
        });
        res.end    
    });

app.route('/submissions/:submission_id/v').get((req,res)=>{
        Submission.findByIdAndUpdate( req.params.submission_id,{statut:'v'},(err,submission)=>{
            res.redirect('/submissionsS')
        })
        res.end    
    })

    app.route('/submissions/:submission_id/r').get((req,res)=>{
        Submission.findByIdAndUpdate( req.params.submission_id,{statut:'r'},(err,submission)=>{
            res.redirect('/submissionsS')
        })
        res.end    
    })

app.route('/connexion').get((req,res)=>{
        res.render('pages/connexion')
        res.end    
    });
app.route('/connexion').post(passport.authenticate('local',{
    successRedirect:'/submissions',
    failureRedirect:'/',
    failureFlash:true
}))

app.route('/inscription').get((req,res)=>{
        res.render('pages/inscription')
        res.end    
    });
app.route('/inscription').post((req,res)=>{
        let user = new User()
        user.nom = req.body.nom
        user.mail = req.body.mail
        //const hashedPasse =  bcrypt.hash(req.body.passe,10)
        //user.passe = hashedPasse
        user.passe = req.body.passe
        user.save(function(err){
            if(err){
                res.send(err)
            }
        res.render('pages/connexion')
        });
    });

app.listen('8081',function(){
    console.log('listening on port 8081')
})