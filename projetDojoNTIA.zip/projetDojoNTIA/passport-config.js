const LocalStrategy = require('passport-local').Strategy
//const bcrypt = require('bcrypt')


module.exports.fonction = function initialize(passport){

    const authenticateUser = async (mail,passe,done)=>{
        User.findOne({mail:mail},(err,theuser)=>{
            if(err){
                resp.send(err);
            }
            const user = theuser
        });        
        if(user == null){ return DocumentTimeline(null,false,{message:'Pas d utilsateur ayant ce mail.'})}

        try {
            if( passe,user.passe){
                return done(null,user)
            }else{ return done(null,false,{message:'Mot de passe incorrect.'})}
        } catch (error) { return done(error) }
    }

    passport.use(new LocalStrategy({usernameField:'mail'},
    authenticateUser))
    passport.serializeUser((user,done)=>{})
    passport.deserializeUser((id,done)=>{})
}